USE pubs;
SELECT titles.pub_id, publishers.pub_name
FROM publishers
LEFT JOIN titles ON publishers.pub_id = titles.pub_id
WHERE publishers.pub_id not in (select titles.pub_id from titles);