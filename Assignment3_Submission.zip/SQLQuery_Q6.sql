
--Q6: Show the sql to find all the titles with more than one author.
USE pubs;
SELECT titleauthor.title_id, titles.title
FROM titleauthor
LEFT JOIN titles ON titleauthor.title_id = titles.title_id
GROUP BY titleauthor.title_id, titles.title
HAVING COUNT (titleauthor.title_id) > 1