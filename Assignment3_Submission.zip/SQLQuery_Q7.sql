USE pubs;
SELECT titleauthor.au_id, authors.au_lname
FROM titleauthor
LEFT JOIN authors ON titleauthor.au_id = authors.au_id
GROUP BY titleauthor.au_id, authors.au_lname
HAVING COUNT (titleauthor.au_id) > 1